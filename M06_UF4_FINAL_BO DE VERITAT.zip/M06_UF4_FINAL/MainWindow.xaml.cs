﻿using M06_UF4_FINAL.DAO;
using M06_UF4_FINAL.Model;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace M06_UF4_FINAL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ClassicModelsContext dbContext;
        private DAOManager dao;


        public MainWindow()
        {
            dbContext = new ClassicModelsContext();
            dao = new DAOFactory().createDaoManager(dbContext); dbContext = new ClassicModelsContext();
            InitializeComponent();
            
        }

        private void Import_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                dao.ImportarCSV();
                MessageBox.Show("Importación exitosa.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al importar el archivo CSV: {ex.Message}");
            }
        }

        private void Query1_Click(object sender, RoutedEventArgs e)
        {
            List<Customer> customersWithOrders = dao.GetAllCustomersWithOrders();
            DataGrid.ItemsSource = customersWithOrders;
        }

        private void Query3_Click(object sender, RoutedEventArgs e)
        {
            List<object> customersWithOrders = dao.GetProductLinesWithTotalProducts();
            DataGrid.ItemsSource = customersWithOrders;
        }

        private void Query4_Click(object sender, RoutedEventArgs e)
        {
            List<object> customersWithOrders = dao.GetAllOrdersWithCustomerNameAndDetails();
            DataGrid.ItemsSource = customersWithOrders;
        }

        private void Query5_Click(object sender, RoutedEventArgs e)
        {
            DateTime principi = Data1.SelectedDate ?? DateTime.MinValue;
            DateTime final = Data2.SelectedDate ?? DateTime.MaxValue;

            List<Order> customersWithOrders = dao.GetOrdersBetweenDates(principi, final);
            DataGrid.ItemsSource = customersWithOrders;
        }

        private void Query6_Click(object sender, RoutedEventArgs e)
        {
            string ciutat = Ciutat.Text.ToString();

            List<Customer> customersWithOrders = dao.GetCustomersFromCity(ciutat);
            DataGrid.ItemsSource = customersWithOrders;
        }

        private void Query7_Click(object sender, RoutedEventArgs e)
        {
            List<Order> customersWithOrders = dao.GetOrdersWithCustomerInfo();
            DataGrid.ItemsSource = customersWithOrders;
        }

        private void Query8_Click(object sender, RoutedEventArgs e)
        {
            List<OrderDetail> customersWithOrders = dao.GetOrderDetailsWithProductInfo();
            DataGrid.ItemsSource = customersWithOrders;
        }

        private void Query9_Click(object sender, RoutedEventArgs e)
        {
            int customersWithOrders = dao.GetTotalProductsInStock();
            MessageBox.Show($"El total de productes en stock és: {customersWithOrders}");
        }

        private void Query2_Click(object sender, RoutedEventArgs e)
        {
            string jobTitle = JobTitle.Text.ToString();
            List<object> employees = dao.GetEmployeesByJobTitle(jobTitle);
            DataGrid.ItemsSource = employees;
        }

        private void Query10_Click(object sender, RoutedEventArgs e)
        {
            List<object> employees = dao.GetOrderTotalSales();
            DataGrid.ItemsSource = employees;
        }

        private void Query11_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(customerNumber.Text, out _))
            {
                int lol = int.Parse(customerNumber.Text);

                List<object> employees = dao.GetCustomerOrdersWithDetails(lol);
                DataGrid.ItemsSource = employees;
            }
            else
            {
                MessageBox.Show("Només es poden introduïr números enters", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                customerNumber.Clear();
            }
        }

        private void Query12_Click(object sender, RoutedEventArgs e)
        {
            List<object> employees = dao.GetEmployeesWithOffices();
            DataGrid.ItemsSource = employees;
        }
    }
}