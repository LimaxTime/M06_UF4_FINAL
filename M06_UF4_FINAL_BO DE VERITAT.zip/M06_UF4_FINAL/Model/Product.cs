﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.Model
{
    public class Product
    {
        public Product() { OrderDetails = new HashSet<OrderDetail>(); }

        [Key]
        [StringLength(15)]
        public string ProductCode { get; set; }

        [StringLength(70)]
        public string ProductName { get; set; }

        [StringLength(50)]
        [ForeignKey("ProductLineCode")]
        public ProductLine ProductLine { get; set; }

        [StringLength(10)]
        public string ProductScale { get; set; }

        [StringLength(50)]
        public string ProductVendor { get; set; }

        [Column(TypeName = "text")]
        public string ProductDescription { get; set; }

        [Column(TypeName = "smallint(6)")]
        public short QuantityInStock { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal BuyPrice { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal MSRP { get; set; }

        public ICollection<OrderDetail> OrderDetails { get; set; }

    }
}
