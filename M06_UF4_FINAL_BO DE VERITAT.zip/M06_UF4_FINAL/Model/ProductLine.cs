﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.Model
{
    public class ProductLine
    {
        public ProductLine() { Products = new HashSet<Product>(); }

        [Key]
        [StringLength(50)]
        public string ProductLineCode { get; set; }

        [MaxLength(4000)]
        public string TextDescription { get; set; }

        [Column(TypeName = "mediumtext")]
        public string HtmlDescription { get; set; }

        [Column(TypeName = "mediumblob")]
        public byte[] Image { get; set; }

        public ICollection<Product> Products { get; set; }
    }
}
