﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.Model
{
    public class OrderDetail
    {
        [Key]
        [ForeignKey("OrderNumber")]
        [Column(TypeName = "int(11)")]
        public int OrderNumber { get; set; }
        public Order Order { get; set; }

        [Key]
        [ForeignKey("ProductCode")]
        [StringLength(15)]
        public string ProductCode { get; set; }
        public Product Product { get; set; }

        [Column(TypeName = "int(11)")]
        public int QuantityOrdered { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal PriceEach { get; set; }

        [Column(TypeName = "smallint(6)")]
        public short OrderLineNumber { get; set; }




    }
}
