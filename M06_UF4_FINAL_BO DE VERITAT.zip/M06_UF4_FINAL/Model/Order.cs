﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.Model
{
    public class Order
    {
        public Order() { OrderDetails = new HashSet<OrderDetail>(); }

        [Key]
        [Column(TypeName = "int(11)")]
        public int OrderNumber { get; set; }

        [Column(TypeName = "date")]
        public DateTime OrderDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime RequiredDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ShippedDate { get; set; }

        [StringLength(15)]
        public string Status { get; set; }

        [Column(TypeName = "text")]
        public string Comments { get; set; }

        public int CustomerNumber { get; set; }

        [ForeignKey("CustomerNumber")]
        public Customer Customer { get; set; }

        public ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
