﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace M06_UF4_FINAL.Model
{
    public class Customer
    {
        public Customer() { Payments = new HashSet<Payment>(); Orders = new HashSet<Order>(); }

        [Key]
        public int CustomerNumber { get; set; }

        [StringLength(50)]
        public string CustomerName { get; set; }

        [StringLength(50)]
        public string ContactLastName { get; set; }

        [StringLength(50)]
        public string ContactFirstName { get; set; }

        [StringLength(50)]
        public string Phone { get; set; }

        [StringLength(50)]
        public string AddressLine1 { get; set; }

        [StringLength(50)]
        public string AddressLine2 { get; set; }

        [StringLength(50)]
        public string City { get; set; }

        [StringLength(50)]
        public string State { get; set; }

        [StringLength(15)]
        public string PostalCode { get; set; }

        [StringLength(50)]
        public string Country { get; set; }

        [ForeignKey("SalesRepEmployee")]
        public int? SalesRepEmployeeNumber { get; set; }

        public Employee SalesRepEmployee { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public double? CreditLimit { get; set; }

        public ICollection<Payment> Payments { get; set; }
        public ICollection<Order> Orders { get; set; }

    }

}
