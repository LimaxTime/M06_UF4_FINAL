﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.Model
{
    public class Employee
    {

        public Employee() { Customers = new HashSet<Customer>(); }

        [Key]
        public int EmployeeNumber { get; set; }

        [StringLength(50)]
        public string LastName { get; set; }

        [StringLength(50)]
        public string FirstName { get; set; }

        [StringLength(10)]
        public string Extension { get; set; }

        [StringLength(100)]
        public string Email { get; set; }

        public string OfficeId { get; set; }

        public Office Office { get; set; }

        [ForeignKey("ReportsTo")]
        public int? ReportsToEmployeeNumber { get; set; }

        public Employee ReportsTo { get; set; }

        [StringLength(50)]
        public string JobTitle { get; set; }

        public ICollection<Customer> Customers { get; set; }
        public ICollection<Employee> Employees { get; set; }
    }
}
