﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.Model
{
    public class Payment
    {
        [Key]
        [ForeignKey("CustomerNumber")]
        public int CustomerNumber { get; set; }
        public Customer Customer { get; set; }

        [Key]
        [StringLength(50)]
        public string CheckNumber { get; set; }

        [Column(TypeName = "date")]
        public DateTime PaymentDate { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal Amount { get; set; }
    }
}
