﻿using M06_UF4_FINAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.DAO
{
    internal class DAOFactory
    {
        public DAOManager createDaoManager(ClassicModelsContext DbContext)
        {
            return new DAOManagerImpl(DbContext);
        }
    }
}
