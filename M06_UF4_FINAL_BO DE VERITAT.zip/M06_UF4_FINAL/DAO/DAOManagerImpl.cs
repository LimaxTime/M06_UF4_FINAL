﻿using CsvHelper;
using CsvHelper.Configuration;
using M06_UF4_FINAL.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Globalization;
using System.IO;

namespace M06_UF4_FINAL.DAO
{
    internal class DAOManagerImpl : DAOManager
    {
        private ClassicModelsContext dbContext;

        public DAOManagerImpl(ClassicModelsContext dbContext)
        {
            this.dbContext = dbContext;
        }

        #region Imports
        public void ImportarCSV()
        {
            ImportFromCSV<ProductLine>("CSV/ProductLines.csv", ImportProductLines);
            ImportFromCSV<Product>("CSV/Products.csv", ImportProducts);
            ImportFromCSV<Office>("CSV/Offices.csv", ImportOffices);
            ImportFromCSV<Employee>("CSV/Employees.csv", ImportEmployees);
            ImportFromCSV<Customer>("CSV/Customers.csv", ImportCustomers);
            ImportFromCSV<Payment>("CSV/Payments.csv", ImportPayments);
            ImportFromCSV<Order>("CSV/Orders.csv", ImportOrders);
            ImportFromCSV<OrderDetail>("CSV/OrderDetails.csv", ImportOrderDetails);
        }

        private void ImportFromCSV<T>(string filePath, Action<string> importMethod)
        {
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    importMethod(filePath);
                }
            }
        }

        public static T? DonarTipus<T>(string value) where T : struct //Converteix l'string al tipus que ha de ser
        {
            if (string.Equals(value, "NULL", StringComparison.OrdinalIgnoreCase))
            {
                return null; 
            }
            else
            {
                return (T)Convert.ChangeType(value, typeof(T));
            }
        }

        public static string IfNull(string value)
        {
            return string.Equals(value, "NULL", StringComparison.OrdinalIgnoreCase) ? null : value;
        }

        public void ImportOrderDetails(string fileName)
        {
            var existingOrderDetailNumbers = dbContext.OrderDetails.Select(od => od.OrderNumber).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var orderNumber = int.Parse(csv.GetField("orderNumber"));
                    if (!existingOrderDetailNumbers.Contains(orderNumber))
                    {
                        var orderDetail = new OrderDetail
                        {
                            OrderNumber = orderNumber,
                            ProductCode = csv.GetField("productCode"),
                            QuantityOrdered = int.Parse(csv.GetField("quantityOrdered")),
                            PriceEach = decimal.Parse(csv.GetField("priceEach")),
                            OrderLineNumber = short.Parse(csv.GetField("orderLineNumber"))
                        };

                        AddOrderDetail(orderDetail);
                    }
                }
                dbContext.SaveChanges();
            }
        }

        public void ImportOrders(string fileName)
        {
            var existingOrderNumbers = dbContext.Orders.Select(o => o.OrderNumber).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var orderNumber = int.Parse(csv.GetField("orderNumber"));
                    if (!existingOrderNumbers.Contains(orderNumber))
                    {
                        var order = new Order
                        {
                            OrderNumber = orderNumber,
                            OrderDate = DateTime.Parse(csv.GetField("orderDate")),
                            RequiredDate = DateTime.Parse(csv.GetField("requiredDate")),
                            ShippedDate = DonarTipus<DateTime>(csv.GetField("shippedDate")),
                            Status = IfNull(csv.GetField("status")),
                            Comments = IfNull(csv.GetField("comments")),
                            CustomerNumber = int.Parse(csv.GetField("customerNumber"))
                        };

                        AddOrder(order);
                    }
                }

                dbContext.SaveChanges();
            }
        }

        public void ImportPayments(string fileName)
        {
            var existingCheckNumbers = dbContext.Payments.Select(p => p.CheckNumber).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var checkNumber = csv.GetField("checkNumber");
                    if (!existingCheckNumbers.Contains(checkNumber))
                    {
                        var payment = new Payment
                        {
                            CustomerNumber = int.Parse(csv.GetField("customerNumber")),
                            CheckNumber = checkNumber,
                            PaymentDate = DateTime.Parse(csv.GetField("paymentDate")),
                            Amount = decimal.Parse(csv.GetField("amount"))
                        };

                        AddPayment(payment);
                    }
                }

                dbContext.SaveChanges();
            }
        }

        public void ImportCustomers(string fileName)
        {
            var existingCustomerNumbers = dbContext.Customers.Select(c => c.CustomerNumber).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var customerNumber = int.Parse(csv.GetField("customerNumber"));
                    if (!existingCustomerNumbers.Contains(customerNumber))
                    {
                        var customer = new Customer
                        {
                            CustomerNumber = customerNumber,
                            CustomerName = IfNull(csv.GetField("customerName")),
                            ContactLastName = IfNull(csv.GetField("contactLastName")),
                            ContactFirstName = IfNull(csv.GetField("contactFirstName")),
                            Phone = IfNull(csv.GetField("phone")),
                            AddressLine1 = IfNull(csv.GetField("addressLine1")),
                            AddressLine2 = IfNull(csv.GetField("addressLine2")),
                            City = IfNull(csv.GetField("city")),
                            State = IfNull(csv.GetField("state")),
                            PostalCode = IfNull(csv.GetField("postalCode")),
                            Country = IfNull(csv.GetField("country")),
                            SalesRepEmployeeNumber = DonarTipus<int>(csv.GetField("salesRepEmployeeNumber")),
                            CreditLimit = DonarTipus<double>(csv.GetField("creditLimit"))
                        };

                        AddCustomer(customer);
                    }
                }

                dbContext.SaveChanges();
            }
        }

        public void ImportEmployees(string fileName)
        {
            var existingEmployeeNumbers = dbContext.Employees.Select(e => e.EmployeeNumber).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var employeeNumber = int.Parse(csv.GetField("employeeNumber"));
                    if (!existingEmployeeNumbers.Contains(employeeNumber))
                    {
                        var employee = new Employee
                        {
                            EmployeeNumber = employeeNumber,
                            LastName = IfNull(csv.GetField("lastName")),
                            FirstName = IfNull(csv.GetField("firstName")),
                            Extension = IfNull(csv.GetField("extension")),
                            Email = IfNull(csv.GetField("email")),
                            OfficeId = IfNull(csv.GetField("officeCode")),
                            ReportsToEmployeeNumber = DonarTipus<int>(csv.GetField("reportsTo")),
                            JobTitle = IfNull(csv.GetField("jobTitle"))
                        };

                        AddEmployee(employee);
                    }
                }

                dbContext.SaveChanges();
            }
        }

        public void ImportOffices(string fileName)
        {
            var existingOfficeCodes = dbContext.Offices.Select(o => o.OfficeCodeId).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var officeCode = IfNull(csv.GetField("officeCode"));
                    if (!existingOfficeCodes.Contains(officeCode))
                    {
                        var office = new Office
                        {
                            OfficeCodeId = officeCode,
                            City = IfNull(csv.GetField("city")),
                            Phone = IfNull(csv.GetField("phone")),
                            AddressLine1 = IfNull(csv.GetField("addressLine1")),
                            AddressLine2 = IfNull(csv.GetField("addressLine2")),
                            State = IfNull(csv.GetField("state")),
                            Country = IfNull(csv.GetField("country")),
                            PostalCode = IfNull(csv.GetField("postalCode")),
                            Territory = IfNull(csv.GetField("territory"))
                        };

                        AddOffice(office);
                    }
                }
                dbContext.SaveChanges();
            }
        }


        public void ImportProducts(string fileName)
        {
            var existingProductCodes = dbContext.Products.Select(p => p.ProductCode).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var productCode = IfNull(csv.GetField("productCode"));
                    if (!existingProductCodes.Contains(productCode))
                    {
                        var product = new Product
                        {
                            ProductCode = productCode,
                            ProductName = IfNull(csv.GetField("productName")),
                            ProductLine = dbContext.ProductLines.FirstOrDefault(pl => pl.ProductLineCode == IfNull(csv.GetField("productLine"))),
                            ProductScale = IfNull(csv.GetField("productScale")),
                            ProductVendor = IfNull(csv.GetField("productVendor")),
                            ProductDescription = IfNull(csv.GetField("productDescription")),
                            QuantityInStock = (short)DonarTipus<short>(csv.GetField("quantityInStock")),
                            BuyPrice = (decimal)DonarTipus<decimal>(csv.GetField("buyPrice")),
                            MSRP = (decimal)DonarTipus<decimal>(csv.GetField("MSRP"))
                        };

                        AddProduct(product);
                    }
                }
                dbContext.SaveChanges();
            }
        }


        public void ImportProductLines(string fileName)
        {
            var existingProductLineCodes = dbContext.ProductLines.Select(pl => pl.ProductLineCode).ToList();

            using (var reader = new StreamReader(fileName))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var productLineCode = IfNull(csv.GetField("productLine"));
                    if (!existingProductLineCodes.Contains(productLineCode))
                    {
                        var productLine = new ProductLine
                        {
                            ProductLineCode = productLineCode,
                            TextDescription = IfNull(csv.GetField("textDescription")),
                            HtmlDescription = IfNull(csv.GetField("htmlDescription")),
                            Image = ConverteixByte(csv.GetField("image"))
                        };

                        AddProductLine(productLine);
                    }
                }

                dbContext.SaveChanges();
            }
        }



        public static byte[] ConverteixByte(string value)//Converteix a bite
        {
            if (string.Equals(value, "NULL", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }
            else
            {
                return Enumerable.Range(0, value.Length)
                                 .Where(x => x % 2 == 0)
                                 .Select(x => Convert.ToByte(value.Substring(x, 2), 16))
                                 .ToArray();
            }
        }

        private void AddCustomer(Customer customer)
        {
            dbContext.Customers.Add(customer);
        }

        private void AddEmployee(Employee employee)
        {
            dbContext.Employees.Add(employee);
        }

        private void AddOffice(Office office)
        {
            dbContext.Offices.Add(office);
        }

        private void AddOrderDetail(OrderDetail orderDetail)
        {
            dbContext.OrderDetails.Add(orderDetail);
        }

        private void AddOrder(Order order)
        {
            dbContext.Orders.Add(order);
        }

        private void AddPayment(Payment payment)
        {
            dbContext.Payments.Add(payment);
        }

        private void AddProduct(Product product)
        {
            dbContext.Products.Add(product);
        }

        private void AddProductLine(ProductLine productLine)
        {
            dbContext.ProductLines.Add(productLine);
        }
        #endregion

        #region Querys

        //1
        public List<Customer> GetAllCustomersWithOrders()
        {
            return dbContext.Customers
                .Include(c => c.Orders)
                .ToList();
        }

        //2
        public List<object> GetEmployeesByJobTitle(string jobTitle)
        {
            return dbContext.Employees
                .Where(e => e.JobTitle == jobTitle)
                .Select(e => new
                {
                    e.EmployeeNumber,
                    e.LastName,
                    e.FirstName,
                    e.Extension,
                    e.Email,
                    e.JobTitle
                })
                .ToList<object>();
        }

        //3
        public List<object> GetProductLinesWithTotalProducts()
        {
            return dbContext.ProductLines
                .Select(pl => new
                {
                    ProductLine = pl,
                    TotalProducts = pl.Products.Count
                })
                .ToList<object>();
        }

        //4
        public List<object> GetAllOrdersWithCustomerNameAndDetails()
        {
            return dbContext.Orders
                .Include(o => o.OrderDetails)
                .Select(o => new
                {
                    o.OrderNumber,
                    o.OrderDate,
                    o.RequiredDate,
                    o.ShippedDate,
                    o.Status,
                    o.Comments,
                    o.Customer.CustomerName,
                    o.CustomerNumber
                })
                .ToList<object>();
        }
        //5
        public List<Order> GetOrdersBetweenDates(DateTime startDate, DateTime endDate)
        {
            return dbContext.Orders
                .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                .OrderBy(o => o.OrderDate)
                .ToList();
        }
        //6
        public List<Customer> GetCustomersFromCity(string city)
        {
            return dbContext.Customers
                .Where(c => c.City == city)
                .OrderBy(c => c.CustomerName)
                .ToList();
        }
        //7
        public List<Order> GetOrdersWithCustomerInfo()
        {
            return dbContext.Orders
                .Include(o => o.Customer)
                .ToList();
        }
        //8
        public List<OrderDetail> GetOrderDetailsWithProductInfo()
        {
            return dbContext.OrderDetails
                .Include(od => od.Product)
                .ToList();
        }
        //9
        public int GetTotalProductsInStock()
        {
            return dbContext.Products.Sum(p => p.QuantityInStock);
        }
        //10
        public List<object> GetOrderTotalSales()
        {
            return dbContext.Orders
                .Select(o => new
                {
                    OrderNumber = o.OrderNumber,
                    TotalSalesAmount = (int)Math.Round(o.OrderDetails.Sum(od => od.QuantityOrdered * od.PriceEach))
                })
                .ToList<object>();
        }
        //11
        public List<object> GetCustomerOrdersWithDetails(int customerNumber)
        {
            return dbContext.Orders
                .Where(o => o.CustomerNumber == customerNumber)
                .Select(o => new
                {
                    o.OrderNumber,
                    o.OrderDate,
                    o.RequiredDate,
                    o.ShippedDate,
                    o.Status,
                    o.CustomerNumber,
                })
                .ToList<object>();
        }
        //12
        public List<object> GetEmployeesWithOffices()
        {
            return dbContext.Employees
                .Include(e => e.Office)
                .Select(e => new
                {
                    e.EmployeeNumber,
                    e.LastName,
                    e.FirstName,
                    e.Extension,
                    e.Email,
                    e.JobTitle,
                    Office = new
                    {
                        e.Office.OfficeCodeId,
                        e.Office.City,
                        e.Office.Phone,
                        e.Office.AddressLine1,
                        e.Office.AddressLine2,
                        e.Office.State,
                        e.Office.Country,
                        e.Office.PostalCode,
                        e.Office.Territory
                    }
                })
                .ToList<object>();
        }
        #endregion


    }
}
