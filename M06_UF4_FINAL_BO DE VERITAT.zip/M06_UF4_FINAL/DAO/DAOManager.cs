﻿using M06_UF4_FINAL.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_UF4_FINAL.DAO
{
    internal interface DAOManager
    {
        void ImportarCSV();

        //1
        List<Customer> GetAllCustomersWithOrders();
        //2
        public List<object> GetEmployeesByJobTitle(string jobTitle);
        //3
        public List<object> GetProductLinesWithTotalProducts();
        //4
        public List<object> GetAllOrdersWithCustomerNameAndDetails();
        //5
        public List<Order> GetOrdersBetweenDates(DateTime startDate, DateTime endDate);
        //6
        public List<Customer> GetCustomersFromCity(string city);
        //7
        public List<Order> GetOrdersWithCustomerInfo();
        //8
        public List<OrderDetail> GetOrderDetailsWithProductInfo();
        //9
        public int GetTotalProductsInStock();
        //10
        public List<object> GetOrderTotalSales();
        //11
        public List<object> GetCustomerOrdersWithDetails(int customerNumber);
        //12
        public List<object> GetEmployeesWithOffices();


    }
}
